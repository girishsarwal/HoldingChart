﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HoldingChartUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public Company HoldingCompany1 = new Company() { Name = "Holding Company 1", TotalCompanyCapital = 100000, Code = "HC0001"};
        public Company HoldingCompany2 = new Company() { Name = "Holding Company 2", TotalCompanyCapital = 5000000, Code = "HC0002", Recurse = false};
        public Company HoldingCompany3 = new Company() { Name = "Holding Company 3", TotalCompanyCapital = 0, Code = "HC0003" };

        public Company SubsidaryLongulf = new Company() { Name = "Subsidary Longulf", TotalCompanyCapital = 50000, Code = "SLF"};
        public Company Property1 = new Company() { Name = "Property 1", TotalCompanyCapital = 25000, Code = "PROP1"};
        public Company LongulfUK = new Company() { Name = "LongulfUK", TotalCompanyCapital = 20000, Code = "LULFUK" };
        public Company LCLT = new Company() { Name = "LCLT", TotalCompanyCapital = 15000, Code = "LCLT"};
        public Company Sub2 = new Company() { Name = "Sub 2", TotalCompanyCapital = 15000, Code = "SUB2" };
        public Company Sub4 = new Company() { Name = "Sub 4", TotalCompanyCapital = 15000, Code = "SUB4" };
        public Company Sub5 = new Company() { Name = "Sub 5", TotalCompanyCapital = 15000, Code = "SUB5" };
        public Company CEPAC = new Company() { Name = "CEPAC", TotalCompanyCapital = 100000, Code = "CEPAC" };
        public Company Property2 = new Company() { Name = "Property2", TotalCompanyCapital = 1000000, Code = "PROP2" };
        public Company Property3 = new Company() { Name = "Property3", TotalCompanyCapital = 2000000, Code = "PROP3"};

        public FamilyMember FM1 = new FamilyMember() { Name = "Family Member 1", Code = "FM1"};
        public FamilyMember FM2 = new FamilyMember() { Name = "Family Member 2", Code = "FM2" };
        public FamilyMember FM3 = new FamilyMember() { Name = "Family Member 3", Code = "FM3" };
        public FamilyMember FM4 = new FamilyMember() { Name = "Family Member 4", Code = "FM4" };
        public FamilyMember FM5 = new FamilyMember() { Name = "Family Member 5", Code = "FM5" };

        public ThirdParty TP = new ThirdParty() { Name = "Third Party", Code = "TP"};

        public List<Holding> holdings = new List<Holding>();

        void BuildHoldings()
        {
            holdings.Clear();

            holdings.Add(new Holding() { Comp = HoldingCompany1, ShareHoldingPercentage = 20, ShareHolder = FM1 });
            holdings.Add(new Holding() { Comp = HoldingCompany1, ShareHoldingPercentage = 30, ShareHolder = FM2 });
            holdings.Add(new Holding() { Comp = HoldingCompany1, ShareHoldingPercentage = 25, ShareHolder = FM3 });
            holdings.Add(new Holding() { Comp = HoldingCompany1, ShareHoldingPercentage = 25, ShareHolder = HoldingCompany2 });

            holdings.Add(new Holding() { Comp = HoldingCompany2, ShareHoldingPercentage = 5, ShareHolder = TP });
            holdings.Add(new Holding() { Comp = HoldingCompany2, ShareHoldingPercentage = 60, ShareHolder = FM4 });
            holdings.Add(new Holding() { Comp = HoldingCompany2, ShareHoldingPercentage = 20, ShareHolder = FM1 });
            holdings.Add(new Holding() { Comp = HoldingCompany2, ShareHoldingPercentage = 15, ShareHolder = FM5 });

            holdings.Add(new Holding() { Comp = SubsidaryLongulf, ShareHoldingPercentage = 50, ShareHolder = HoldingCompany1 });
            holdings.Add(new Holding() { Comp = SubsidaryLongulf, ShareHoldingPercentage = 5, ShareHolder = TP });
            holdings.Add(new Holding() { Comp = SubsidaryLongulf, ShareHoldingPercentage = 45, ShareHolder = HoldingCompany3 });

            holdings.Add(new Holding() { Comp = Property1, ShareHoldingPercentage = 100, ShareHolder = SubsidaryLongulf });

            holdings.Add(new Holding() { Comp = LongulfUK, ShareHoldingPercentage = 50, ShareHolder = SubsidaryLongulf });
            holdings.Add(new Holding() { Comp = LongulfUK, ShareHoldingPercentage = 25, ShareHolder = HoldingCompany2 });
            holdings.Add(new Holding() { Comp = LongulfUK, ShareHoldingPercentage = 25, ShareHolder = HoldingCompany1 });

            holdings.Add(new Holding() { Comp = LCLT, ShareHoldingPercentage = 100, ShareHolder = SubsidaryLongulf });

            holdings.Add(new Holding() { Comp = Sub2, ShareHoldingPercentage = 100, ShareHolder = SubsidaryLongulf });

            holdings.Add(new Holding() { Comp = Sub4, ShareHoldingPercentage = 100, ShareHolder = SubsidaryLongulf });

            holdings.Add(new Holding() { Comp = Sub5, ShareHoldingPercentage = 100, ShareHolder = SubsidaryLongulf });

            holdings.Add(new Holding() { Comp = CEPAC, ShareHoldingPercentage = 100, ShareHolder = LongulfUK });

            holdings.Add(new Holding() { Comp = Property2, ShareHoldingPercentage = 100, ShareHolder = CEPAC });

            holdings.Add(new Holding() { Comp = Property3, ShareHoldingPercentage = 80, ShareHolder = CEPAC });
            holdings.Add(new Holding() { Comp = Property3, ShareHoldingPercentage = 20, ShareHolder = HoldingCompany2 });


            //holdings.Add(new Holding() { Comp = HoldingCompany1, ShareHoldingPercentage = 20, ShareHolder = FM1 });
            //holdings.Add(new Holding() { Comp = SubsidaryLongulf, ShareHoldingPercentage = 50, ShareHolder = HoldingCompany1 });
            //holdings.Add(new Holding() { Comp = SubsidaryLongulf, ShareHoldingPercentage = 30, ShareHolder = FM1 });

        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            BuildHoldings();
            HoldingProcessor.Holdings = holdings;

            string path = Path.Combine(Environment.CurrentDirectory, "holdingchart.htm.template");
            string template = File.ReadAllText(path);
            string data = HoldingProcessor.ProcessHoldings(HoldingCompany1, null);
            template = template.Replace("{{ data }}", data);

            string outputPath = Path.GetTempPath() + Guid.NewGuid().ToString() + ".htm";
            File.WriteAllText(outputPath, template);

            Process.Start(outputPath);
        }
    }
}
